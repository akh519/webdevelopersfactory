from django.contrib import admin
from web.models import Contact

# Register your models here.
admin.site.register(Contact)