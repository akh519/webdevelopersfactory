from django.contrib import admin
from django.urls import path
from web import views


#django admin header customization
admin.site.site_header = " login to web developers factory"
admin.site.site_title = "Welcome to WDF Dashboard"
admin.site.index_title = "Welcome to this Portal"


urlpatterns = [
    path ("", views.index, name="home"),
    path ("aboutus", views.aboutus, name="aboutus"),
    path ("services", views.services, name="services"),
    path ("contact", views.contact, name="contact"),
    path ("websites", views.websites, name="websites"),
    path ("presentation", views.presentation, name="presentation"),
    path ("logo", views.logo, name="logo"),
    path ("template", views.template, name="template"),
    path ("themeweb", views.themeweb, name="themeweb"),
    path ("sourcecode", views.sourcecode, name="sourcecode"),
    path ("slide", views.slide, name="slide"),
    path ("themepre", views.themepre, name="themepre"),
    path ("animation", views.animation, name="animation"),
    path ("icons", views.icons, name="icons"),
    path ("designs", views.designs, name="designs"),
    path ("animatedlogo", views.animatedlogo, name="animatedlogo"),
    path ("consid", views.consid, name="consid"),
    path ("conayu", views.conayu, name="conayu"),
    path ("consho", views.consho, name="consho"),
    path ("conman", views.conman, name="conman"),
     
]
