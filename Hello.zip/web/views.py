from django.shortcuts import render
from web.models import Contact

# Create your views here.

def index(request):
    return render(request, 'index.html')

def aboutus(request):
    return render(request, 'aboutus.html')

def services(request):
    return render(request, 'services.html')

def contact(request):
    if request.method=="POST":
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        desc = request.POST['desc']
        # print(name, email, phone, desc)
        contact = Contact(name=name, email=email, phone=phone, desc=desc)
        contact.save()
        print("The data has been written to the db")
    return render(request, 'contact.html')

def websites(request):
    return render(request, 'website.html')

def presentation(request):
    return render(request, 'presentation.html')

def logo(request):
    return render(request, 'logo.html')

def template(request):
    return render(request, 'template.html')

def themeweb(request):
    return render(request, 'themeweb.html')

def sourcecode(request):
    return render(request, 'sourcecode.html')

def slide(request):
    return render(request, 'slide.html')

def themepre(request):
    return render(request, 'themepre.html')

def animation(request):
    return render(request, 'animation.html')

def icons(request):
    return render(request, 'icons.html')

def designs(request):
    return render(request, 'designs.html')

def animatedlogo(request):
    return render(request, 'animatedlogo.html')

def consid(request):
    return render(request, 'consid.html')

def conayu(request):
    return render(request, 'conayu.html')

def consho(request):
    return render(request, 'consho.html')

def conman(request):
    return render(request, 'conman.html')
